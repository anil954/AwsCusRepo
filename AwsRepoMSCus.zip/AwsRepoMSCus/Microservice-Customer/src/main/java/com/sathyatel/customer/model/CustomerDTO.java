package com.sathyatel.customer.model;

import java.util.List;

public class CustomerDTO {
	private Long phoneNo;
	private String name;
	private String planId;
	private PlanDTO currentPLan;//to set the plandto object into customerdto
	private List<Long> friends;// to set the friends list into customerdto
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public PlanDTO getCurrentPLan() {
		return currentPLan;
	}
	public void setCurrentPLan(PlanDTO currentPLan) {
		this.currentPLan = currentPLan;
	}
	public List<Long> getFriends() {
		return friends;
	}
	public void setFriends(List<Long> friends) {
		this.friends = friends;
	}
}
